# @lojascem/components-react

Biblioteca de componentes WEB em React padronizadas para utilizar em seu projeto.

[Clique aqui para abrir o Storybook](http://aplicacao.lojascem.local:50024/)

---

- [Login](#login)
- [Instalar](#instalar)
- [Atualizar](#atualizar)
- [Features](#features)

## `Login`

`É necessário fazer esse login apenas uma vez`

> ```bash
> setx NODE_EXTRA_CA_CERTS "C:\certs\lojascem.local.crt"
> ```

Coloque o certificado no diretório e reinicie o computador.

> ```bash
> npm config set @lojascem:registry=https://gitea.lojascem.local:53000/api/packages/lojascem/npm/
> ```

> ```bash
> npm config set -- '//gitea.lojascem.local:53000/api/packages/lojascem/npm/:_authToken' "${SEU_TOKEN}"
> ```

## `Instalar`

Instalação da biblioteca:

> ```bash
> npm install @lojascem/components-react
> ```

## `Atualizar`

> ```bash
> npm install @lojascem/components-react@latest
> ```

## `Features`

- [x] ACCORDION
- [x] ALERT
- [x] AVATAR
- [x] BADGE
- [x] BREADCRUMBS
- [x] BUTTON
- [x] CALENDAR
- [x] CALENDAR RANGE
- [x] CARD
- [x] CHARTS
- [x] CHECKBOX
- [x] COMBOBOX
- [x] DATAPICKER
- [x] DATAPICKER RANGE
- [x] DIVIDER
- [x] FAB
- [x] FILEINPUT
- [x] FLEXTABLE
- [x] HEADING
- [x] ICON
- [x] ICON BUTTON
- [x] IMAGE
- [x] LINK
- [x] LISTBOX
- [x] MAP
- [x] MENU BUTTON
- [x] METER GAUGE
- [x] MODAL
- [x] PAGINATION
- [x] PLACELOAD
- [x] POPOVER
- [x] PROGRESS
- [x] RADIO
- [x] SELECTFIELD
- [x] SELECT MULTIPLE
- [x] SLIDER
- [x] SPINNER
- [x] STACK
- [x] STEPS
- [x] SWITCH
- [x] TAB LIST
- [x] TABLE
- [x] TABS
- [x] TEXT
- [x] TEXT AREA
- [x] TEXT FIELD
- [x] TOAST
- [x] TOOGLE BUTTON
- [x] TOOLTIP
- [x] WIDGETS

## Automation

- [] Button
- [] ButtonCircle
- [] Card
- [] Progress
- [] Select
- [] Slider
- [] Switch
- [] Tabs
- [] TextField
